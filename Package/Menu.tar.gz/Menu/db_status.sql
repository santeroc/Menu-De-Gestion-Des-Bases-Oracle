select logins from v$instance;
exit
